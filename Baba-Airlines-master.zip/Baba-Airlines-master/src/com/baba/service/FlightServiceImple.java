package com.baba.service;

import java.util.ArrayList;

import com.baba.dto.FlightDto;

public class FlightServiceImple implements FlightService {

	@Override
	public int addFlight(FlightDto flight) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int modifyFlight(FlightDto flight) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int removeFlight(int flightId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ArrayList<FlightDto> flightList(int flightId) {
		// TODO Auto-generated method stub
		return null;
	}

}
